<?php

require("config.inc.php");
require(MYSQL);

//handle login attempt
if ( $_SERVER['REQUEST_METHOD'] == 'POST' )
{

	include('login.inc.php');

}

include("html/header.html");
?>

<h3> Welcome to the body of this site </h3>
<p> kl;asdjfkl;ajdkl;fjaskl;dfj </p>


<?php



echo '<h3> most poplular pages </h3>';

$query = "SELECT * FROM books";
$r = mysqli_query($dbc, $query);

while ( $row = mysqli_fetch_array($r, MYSQLI_NUM) )
{
	echo "$row[0] and $row[2] <br />";
}


?>

<?php

include("html/footer.html");



?>
