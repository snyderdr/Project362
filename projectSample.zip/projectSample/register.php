<?php

require ('html/header.html');
require ('config.inc.php');
require (MYSQL);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {


	echo $_POST['first_name'];
	echo $_POST['last_name'];
	$ln = $_POST['last_name'];
	$fn = $_POST['first_name'];

	$q = "INSERT INTO users (first_name, last_name) VALUES ('$fn', '$ln')";
	$r = mysqli_query($dbc, $q);
}
?>



<form action="register.php" method="post">

first name <input type="text" name="first_name" />
last name <input type="text" name="last_name" />
<input type="submit" name="submit_button" />

</form>


<?php

include ('html/footer.html');

?>
