<?php

define ('BASE_URI', '/var/www/projectSample/');
define ('BASE_URL', 'localhost');
define ('MYSQL', BASE_URI . 'mysql.inc.php');


//start the session

session_start();
//helper function
