<?php


$e = $_POST['email'];
$p = $_POST['pass'];


$q = "SELECT * FROM users WHERE email = '$e' AND pass = '$p'";

$r = mysqli_query($dbc, $q);

if ( mysqli_num_rows($r) == 1)
{

	$row = mysqli_fetch_array($r, MYSQLI_NUM);

	$_SESSION['user_id'] = $row[0];
	$_SESSION['email'] = $row[3];
}
else
{

	echo "no match for email and password";

}
