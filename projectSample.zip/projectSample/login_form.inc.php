<?php

echo "login form";

?>

<form action="index.php" method="post">

email <input type="text" name="email" /><br />
pass  <input type="text" name="pass" /><br />

<input type="submit" name="submit" value="login" />

</form>
